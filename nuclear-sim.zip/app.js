document.getElementById('gauges').innerHTML = 'Gauges and status displayed here.';
document.getElementById('controls').innerHTML = 'Controls displayed here.';
document.getElementById('log').innerHTML = '<h3>Operator Log</h3>';
document.getElementById('map').innerHTML = '<h3>Evacuation Map</h3><img src="images/pripyat-map.jpg">';
